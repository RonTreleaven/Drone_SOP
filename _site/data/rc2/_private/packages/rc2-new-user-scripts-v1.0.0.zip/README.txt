﻿RC2 New User Bundle

Version: 1.0.0

This package is a controlled onboarding set for Windows PowerShell.

Suggested sequence:
1) Step1
2) Step2
3) Step3
4) Step4
5) Step5B
6) Step9
7) Step6 (DryRun first)
