param(
  [ValidateSet('Mission_B','Mission_A','Mission_C')]
  [string[]]$Roles,
  [switch]$SkipMissionC,
  [switch]$IncludeMissionC,
  [switch]$DryRun,
  [switch]$PromptBeforeCopy
)

$configPointer = Join-Path $env:USERPROFILE "rc2_missions_config_path.txt"
if(-not (Test-Path $configPointer)){
  throw "CONFIG_POINTER_NOT_FOUND. Run Step 1 first."
}

$configPath = (Get-Content $configPointer -Raw).Trim()
if(-not (Test-Path $configPath)){
  throw "CONFIG_NOT_FOUND. Run Step 1 again to regenerate local_config.json."
}

$config = Get-Content $configPath -Raw | ConvertFrom-Json
$root = $config.managerRoot
$logRoot = if($config.logRoot){ $config.logRoot } else { Join-Path $root "LOGS" }
$rolesPath = Join-Path $root "REGISTRY/uuid_roles.json"
if(-not (Test-Path $rolesPath)){
  throw "UUID_ROLES_NOT_FOUND. Run Step 4 first."
}

$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$logFile = Join-Path $logRoot "step6_copy_to_rc2_$stamp.log"
New-Item -ItemType Directory -Force -Path $logRoot | Out-Null

function Write-StepLog {
  param([string]$Level, [string]$Message)
  $entry = "[{0}] [{1}] {2}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Level.ToUpper(), $Message
  $entry | Add-Content -Path $logFile -Encoding UTF8
  Write-Host $entry
}

function Get-MtpChildFolder {
  param($folder, [string]$name)
  if(-not $folder){ return $null }
  foreach($x in $folder.Items()){
    if($x.Name -eq $name){ return $x.GetFolder() }
  }
  return $null
}

function Test-MtpFileExists {
  param($folder, [string]$fileName)
  if(-not $folder){ return $false }
  foreach($x in $folder.Items()){
    if(-not $x.IsFolder -and $x.Name -eq $fileName){
      return $true
    }
  }
  return $false
}

function Wait-ForMtpFile {
  param($folder, [string]$fileName, [int]$TimeoutSeconds = 20)
  $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
  while((Get-Date) -lt $deadline){
    if(Test-MtpFileExists -folder $folder -fileName $fileName){
      return $true
    }
    Start-Sleep -Milliseconds 300
  }
  return (Test-MtpFileExists -folder $folder -fileName $fileName)
}

try {
  Write-StepLog INFO "Step 6 started. Preparing mission-slot RC2 copy operation."

  if($Roles -and ($SkipMissionC -or $IncludeMissionC)){
    throw "PARAMETER_CONFLICT. Use either -Roles or -SkipMissionC/-IncludeMissionC, not both."
  }

  if($SkipMissionC -and $IncludeMissionC){
    throw "PARAMETER_CONFLICT. Use either -SkipMissionC or -IncludeMissionC, not both."
  }

  $roleMap = Get-Content $rolesPath -Raw | ConvertFrom-Json
  if($Roles){
    $roleOrder = @()
    foreach($r in $Roles){
      if($r -notin $roleOrder){
        $roleOrder += $r
      }
    }
    Write-StepLog INFO "Explicit role selection requested (-Roles): $($roleOrder -join ', ')"
  }
  else {
    $roleOrder = @("Mission_B", "Mission_A", "Mission_C")
    if($SkipMissionC){
      $roleOrder = @("Mission_B", "Mission_A")
      Write-StepLog INFO "Mission_C copy skipped for this run by request (-SkipMissionC)."
      Write-Host "[INFO] Default Step 6 behavior includes Mission_C."
    }
    elseif($IncludeMissionC){
      Write-StepLog INFO "-IncludeMissionC specified; Mission_C is already included by default."
    }
  }

  Write-StepLog INFO "Roles selected for copy: $($roleOrder -join ', ')"

  $deployPlan = @()
  foreach($role in $roleOrder){
    $uuid = $roleMap.$role
    if(-not $uuid -or $uuid -notmatch '^[0-9A-F-]{36}$'){
      throw "Invalid UUID for role $role in uuid_roles.json"
    }

    $localFile = Join-Path $root ("{0}/{1}.kmz" -f $role, $uuid)
    if(-not (Test-Path $localFile)){
      throw "Missing staged KMZ for ${role}: $localFile. Run Step 5 deploy prep first."
    }

    $deployPlan += [PSCustomObject]@{
      Role = $role
      UUID = $uuid
      LocalFile = $localFile
      TargetName = "$uuid.kmz"
    }
  }

  Write-StepLog INFO "Deploy plan validated: $($deployPlan.Count) role(s)."

  $shell = New-Object -ComObject Shell.Application
  $pc = $shell.Namespace('shell:MyComputerFolder')
  $rc = $null
  foreach($i in $pc.Items()){
    if($i.Name -like '*DJI RC 2*'){
      $rc = $i
      break
    }
  }
  if(-not $rc){
    throw "DJI RC 2 not found. Connect RC2 by USB, unlock controller, set USB mode to File Transfer (MTP), then retry Step 6."
  }
  Write-StepLog INFO "RC2 device detected: $($rc.Name)"

  $waypoint = $rc.GetFolder()
  $waypoint = Get-MtpChildFolder $waypoint 'Internal shared storage'
  $waypoint = Get-MtpChildFolder $waypoint 'Android'
  $waypoint = Get-MtpChildFolder $waypoint 'data'
  $waypoint = Get-MtpChildFolder $waypoint 'dji.go.v5'
  $waypoint = Get-MtpChildFolder $waypoint 'files'
  $waypoint = Get-MtpChildFolder $waypoint 'waypoint'

  if(-not $waypoint){
    throw "Waypoint folder not found on RC2. Confirm RC2 mission storage exists, then retry Step 6."
  }
  Write-StepLog INFO "Waypoint folder located on RC2."

  $slotFolders = @{}
  foreach($slot in $waypoint.Items()){
    if($slot.IsFolder -and $slot.Name -match '^[0-9A-F-]{36}$'){
      $slotFolders[$slot.Name.ToUpper()] = $slot.GetFolder()
    }
  }

  foreach($item in $deployPlan){
    if(-not $slotFolders.ContainsKey($item.UUID.ToUpper())){
      throw "RC2 slot folder not found for $($item.Role) UUID: $($item.UUID)"
    }
  }

  if($DryRun){
    Write-StepLog INFO "Dry run enabled. No files will be copied to RC2."
    Write-Host ""
    Write-Host "Step 6 Dry Run Preview"
    Write-Host "Role plan:"
    $deployPlan |
      Select-Object Role, UUID, LocalFile, TargetName |
      Format-Table -AutoSize
    Write-Host ""
    Write-Host "[COMPLETE] Dry run finished. No RC2 writes were performed."
    Write-Host "Log file: $logFile"
    return
  }

  if($PromptBeforeCopy){
    Write-Host ""
    Write-Host "Step 6 is ready to copy staged KMZ file(s) to RC2:" -ForegroundColor Yellow
    $deployPlan |
      Select-Object Role, UUID, LocalFile, TargetName |
      Format-Table -AutoSize
    $confirm = (Read-Host "Proceed with RC2 write operations? Enter YES to continue").Trim()
    if($confirm -ne 'YES'){
      Write-StepLog WARN "User canceled RC2 write operation at confirmation prompt."
      Write-Host "[BLOCKED] Copy canceled by user. No RC2 writes were performed."
      Write-Host "Log file: $logFile"
      return
    }
    Write-StepLog INFO "User confirmed RC2 write operation."
  }

  foreach($item in $deployPlan){
    $slotFolder = $slotFolders[$item.UUID.ToUpper()]

    $srcDir = Split-Path $item.LocalFile -Parent
    $srcName = Split-Path $item.LocalFile -Leaf
    $srcNs = $shell.Namespace($srcDir)
    if(-not $srcNs){ throw "Unable to open source folder: $srcDir" }
    $srcItem = $srcNs.ParseName($srcName)
    if(-not $srcItem){ throw "Unable to resolve source item: $($item.LocalFile)" }

    Write-StepLog INFO "Copying $($item.Role) -> RC2 slot $($item.UUID) as $($item.TargetName)"
    # Option 16 keeps copy non-interactive for replace/yes-to-all behavior.
    $slotFolder.CopyHere($srcItem, 16)

    if(-not (Wait-ForMtpFile -folder $slotFolder -fileName $item.TargetName -TimeoutSeconds 25)){
      throw "Timed out waiting for RC2 file after copy: $($item.TargetName) in slot $($item.UUID)"
    }

    Write-StepLog INFO "RC2 copy confirmed for role $($item.Role)."
  }

  Write-StepLog INFO "Step 6 completed successfully."
  Write-Host "Log file: $logFile"
  Write-Host "[PASS] Step 6 validation checks passed."
  Write-Host "[SUCCESS] Step 6 completed successfully."
  Write-Host "[COMPLETE] RC2 slot copies applied for mission slots: $($roleOrder -join ', ')"
}
catch {
  Write-StepLog ERROR $_.Exception.Message
  if($_.FullyQualifiedErrorId){
    Write-StepLog ERROR "FullyQualifiedErrorId: $($_.FullyQualifiedErrorId)"
    Write-Host "Error ID: $($_.FullyQualifiedErrorId)"
  }
  Write-Host "[FAILED] Step 6 failed. See log: $logFile"
  throw
}
