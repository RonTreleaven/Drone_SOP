# Advanced RPAS Practice Log

Canadian Advanced RPAS study record for RT.

## Reference scope

- Canadian Aviation Regulations (CARs), Part IX
- Transport Canada Aeronautical Information Manual (TC AIM), 2025-1
- TP 15263 — Knowledge Requirements for Pilots of Remotely Piloted Aircraft Systems
- Designated Airspace Handbook (DAH)
- Canadian/ICAO NOTAM Q-codes

## Readiness scale

- **GO:** Strong understanding; operational decisions are consistently correct.
- **REVIEW:** Some uncertainty or isolated errors; targeted study recommended.
- **NO-GO:** Safety-critical misunderstanding or repeated errors; review before relying on the topic operationally.

## Running record

### 2026-08-16 — Study plan established

- A short practice session is scheduled daily, beginning around 08:00 Eastern Time.
- Each session contains five rotating multiple-choice questions.
- Answers are verified against Canadian-only authoritative references and include concise explanations.
- Each session ends with a Go/No-Go assessment of weak areas.
- Until question responses are recorded, readiness assessments remain provisional.

#### Baseline readiness

- **Status:** Measured in Practice Set 1 below.

### 2026-08-16 — Practice Set 1

- **Topics:** controlled airspace, maximum altitude, site surveys, VLOS, and NOTAM Q-code structure
- **Score:** 4/5 (80%)
- **Responses:** 1-B, 2-B, 3-B, 4-B, 5-A
- **Correct answers:** 1-B, 2-C, 3-B, 4-B, 5-A

#### Review notes

1. **Controlled airspace — Correct.** Under CAR 901.71, an Advanced operation in controlled airspace requires authorization from the air traffic services provider for the area of operation.
2. **Maximum altitude — Incorrect.** CAR 901.25 permits flight up to 100 ft above a building or structure when the RPA remains less than 200 ft horizontally from it. For a 350-ft building, the applicable limit is therefore 450 ft AGL, absent an SFOC or other applicable authorization.
3. **Site survey — Correct.** CAR 901.27 requires consideration of applicable airspace and NOTAMs, flight routes and altitudes, nearby aircraft operations and aerodromes, obstacles, weather, and applicable separation from people or populated areas.
4. **VLOS — Correct.** CAR 901.11 permits either the pilot or a properly used visual observer to maintain the required visual line-of-sight.
5. **NOTAM Q-code — Correct.** After the initial `Q`, the next two letters identify the subject and the final two identify its condition.

#### Go/No-Go assessment

- **Overall:** REVIEW / conditional GO for continued study
- **Strong areas:** controlled-airspace authorization, site surveys, VLOS, and basic NOTAM Q-code construction
- **Weak area:** applying the structure-proximity altitude provision in CAR 901.25
- **Operational caution:** Before using the structure provision, verify both the structure height and that the aircraft will remain less than 200 ft (61 m) horizontally from it. Do not treat 400 ft AGL as the only possible limit or assume proximity to a structure automatically permits a higher altitude.
- **Next-session focus:** scenario-based altitude limits, horizontal distance, and controlled-airspace authorization boundaries

#### Follow-up clarification — tall structures

- CAR 901.25(1)(b) does not state a maximum height for the qualifying building or structure.
- If the top of a structure is 1,000 ft AGL, the altitude provision can allow operation up to 1,100 ft AGL while the RPA remains less than 200 ft (61 m) horizontally from that structure.
- This provision changes only the section 901.25 altitude ceiling. All other requirements continue to apply, including the applicable operating category, VLOS or other permitted operation type, site survey and NOTAM review, separation from people, aircraft safety, aerodrome procedures, RPAS declaration requirements, and controlled-airspace authorization.
- In controlled airspace, the ATS authorization must cover the intended operational volume and altitude. CAR 901.71(2) is needed only when ATS authorizes an altitude above even the limits permitted by 901.25.

---


Future daily sessions and results will be added below in date order.

### 2026-08-16 — Practice Set 2

- **Topics:** structure-related altitude, controlled-airspace authorization, airport proximity, emergency procedures, and night operations
- **Score:** 3/5 (60%)
- **Responses:** 1-A, 2-A, 3-D, 4-B, 5-C
- **Correct answers:** 1-C, 2-A, 3-C, 4-B, 5-C

#### Review notes

1. **Structure-related altitude — Incorrect.** CAR 901.25(1)(b) requires the RPA to be at a horizontal distance of *less than* 200 ft (61 m) from the building or structure. Exactly 200 ft does not qualify, so the general 400-ft AGL ceiling applies in the scenario.
2. **Controlled-airspace authorization — Correct.** An ATS authorization limited to 300 ft AGL governs the operation. The structure provision does not permit the pilot to disregard a more restrictive authorization.
3. **Airport proximity — Incorrect.** Under the Advanced Operations division, operation less than 3 NM from an airport centre or less than 1 NM from a heliport centre must follow the established RPAS procedure applicable to that airport or heliport. The requirement is not removed merely because the local airspace is uncontrolled.
4. **Lost command-and-control link — Correct.** Emergency procedures must address loss of the C2 link; the procedures must be reviewed before flight and immediately available to each crew member.
5. **Night operation — Correct.** The RPA must be equipped with lights sufficient to make it visible to the pilot or visual observer, and those lights must be turned on.

#### Go/No-Go assessment

- **Overall:** REVIEW
- **Strong areas:** respecting restrictive ATS authorizations, lost-link procedures, and night-lighting requirements
- **Weak areas:** exact regulatory boundary language and airport-proximity procedures in uncontrolled airspace
- **Operational caution:** Treat “less than” as excluding the stated boundary itself: exactly 200 ft does not satisfy the structure provision, while a position less than 3 NM from an airport triggers the established-procedure requirement.
- **Next-session focus:** inclusive versus exclusive regulatory limits, airport/heliport procedures, and interaction between airspace class and aerodrome proximity

---

### 2026-08-17 — Practice Set 3

- **Topics:** structure-related altitude, controlled-airspace authorization, Class F restricted airspace, NOTAM Q-code interpretation, and fatigue
- **Score:** 5/5 (100%)
- **Responses:** 1-B, 2-B, 3-C, 4-B, 5-C
- **Correct answers:** 1-B, 2-B, 3-C, 4-B, 5-C

#### Review notes

1. **Structure-related altitude — Correct.** A 150-ft AGL tower permits operation up to 250 ft AGL when the RPA remains *less than* 200 ft (61 m) horizontally from it. The question's phrase “within 200 ft” was imprecise; exactly 200 ft does not qualify under CAR 901.25(1)(b).
2. **Controlled airspace — Correct.** An Advanced pilot requires ATS authorization to operate in Class D controlled airspace, and the authorization must be readily accessible during the operation.
3. **Class F restricted airspace — Correct.** Flight within active CYR restricted airspace requires authorization from the responsible user or controlling agency; remaining below 400 ft AGL does not remove that requirement.
4. **NOTAM interpretation — Correct.** In `QWULW`, `WU` identifies RPAS activity and `LW` indicates that the activity will take place.
5. **Human factors — Correct.** Noticeable fatigue and impaired concentration require a No-Go decision. A visual observer or reduced operating altitude does not correct pilot impairment.

#### Go/No-Go assessment

- **Overall:** GO on this knowledge check
- **Strong areas:** structure-altitude calculation, controlled and restricted airspace, NOTAM decoding, and fatigue-related decision-making
- **Improvement demonstrated:** The exclusive “less than 200 ft” boundary missed in Practice Set 2 was correctly understood in this set.
- **Cumulative score:** 12/15 (80%) across three practice sets
- **Readiness trend:** REVIEW → REVIEW → GO
- **Next-session focus:** certified airports versus registered aerodromes, airport/heliport proximity procedures, and controlled-airspace status as a separate determination

---

### 2026-08-21 — Practice Set 4

- **Score:** 4/5 (80%) — CONDITIONAL GO
- **Responses:** C, A, C, B, B
- **Correct answers:** C, A, C, B, A
- **Review:** `QOBCE` means obstacle erected, not obstacle-lighting failure.

### 2026-08-21 — Practice Set 5

- **Score:** 5/5 (100%) — GO
- **Responses:** C, B, C, B, B
- **Correct answers:** C, B, C, B, B
- **Improvement:** Correctly distinguished `QOLAS` (obstacle lights unserviceable) from `QOBCE` (obstacle erected).

### 2026-08-21 — Practice Set 6

- **Score:** 4/5 (80%) — CONDITIONAL GO
- **Responses:** C, B, C, C, B
- **Correct answers:** C, B, C, B, B
- **Review:** `CYA` advisory, `CYD` danger, and `CYR` restricted.

### 2026-08-23 — Targeted Review 1

- **Topics:** ATC instructions, NOTAM Q-line vertical qualifiers, advertised events, pilot intervention, and DAH regional numbering
- **Score:** 5/5 (100%) — GO
- **Responses:** B, A, C, C, C
- **Correct answers:** B, A, C, C, C

#### Review notes

1. **ATC instructions — Correct.** A later ATC instruction must be followed even when it changes the conditions of the original controlled-airspace authorization.
2. **NOTAM Q-line — Correct.** `QRRCD` indicates a restricted area is deactivated, and `013/021` is the Q-line filtering band of 1,300–2,100 ft AMSL. Items F and G still provide the exact operational limits.
3. **Advertised event — Correct.** Operating a 249-g RPA at an advertised event requires an SFOC—RPAS unless a specific exception applies; sub-250-g mass alone does not remove the prohibition.
4. **Pilot intervention — Correct.** An RPAS operated under the ordinary Part IX rules must be designed to allow pilot intervention in managing the flight.
5. **DAH regional numbering — Correct.** `CYR518` is an Ontario restricted area because the 501–599 number block identifies Ontario.

#### Go/No-Go assessment

- **Overall:** GO on this targeted knowledge check
- **Improvement demonstrated:** Correctly applied the two prior review points—compliance with subsequent ATC instructions and interpretation of Q-line altitude qualifiers as hundreds of feet AMSL rather than AGL.

### 2026-08-25 — Practice Set 10

- **Topics:** structure-related altitude, exact person-distance boundaries, DND aerodrome authorization, DAH vertical-limit conventions, and compound NOTAM Q-line interpretation
- **Score:** 4/5 (80%) — CONDITIONAL GO
- **Responses:** C, A, C, B, A
- **Correct answers:** C, A, B, B, A

#### Review notes

1. **Structure-related altitude — Correct.** A 600-ft tower permits operation up to 700 ft AGL while the RPA remains less than 200 ft horizontally from it.
2. **Person-distance boundary — Correct.** Exactly 5.0 m falls within the “less than 30 m but not less than 5 m” category; the closer category begins at less than 5 m.
3. **DND aerodrome authorization — Incorrect.** At 2.99 NM from the centre of a DND-operated aerodrome, authorization from the Department of National Defence is specifically required even when the surrounding airspace is uncontrolled. Municipal permission does not replace this authorization.
4. **DAH vertical limits — Correct.** Unqualified DAH altitude limits are ASL and inclusive.
5. **NOTAM Q-line — Correct.** `QWMLW/IV/BO/W` identifies missile, gun, rocket, fireworks or pyrotechnic activity that will take place; it is relevant to IFR and VFR traffic, briefing and flight operations, with navigation-warning scope.

#### Go/No-Go assessment

- **Overall:** CONDITIONAL GO
- **Strong areas:** exact altitude and person-distance boundaries, DAH limit conventions, and compound NOTAM decoding
- **Active review item:** DND aerodrome proximity authorization under CAR 901.47(4), separate from controlled-airspace authorization and municipal permission
- **Next-session focus:** DND versus civilian aerodrome procedures and authorization sources

### Current cumulative assessment

- **Scored rounds:** 8
- **Score:** 34/40 (85.0%)
- **Readiness trend:** REVIEW → REVIEW → GO → CONDITIONAL GO → GO → CONDITIONAL GO → GO → CONDITIONAL GO
- **Pending:** Practice Sets 7, 8, and 9 have been issued but not yet answered or scored.

---
