# Canadian Advanced RPAS Mastery System

## Purpose
Canonical cross-device store for Advanced RPAS quizzes, question history, answers, authority links, weak-topic tracking, and mastery/readiness calculations.

## Files
- `Advanced_RPAS_Practice_Log.md` — human-readable audit/history
- `practice_sessions.json` — canonical structured session-level data
- `question_bank.jsonl` — question-level database (schema initialized; populate as full questions are recovered)
- `gold_sources.csv` — authoritative source catalog
- `Advanced_RPAS_Practice_Log_original.md` — untouched source attachment

## Integrity rule
Do not merge recovered round scores into verified cumulative metrics until the underlying question/answer records are recovered. Preserve `verification_status`.

## Recommended OneDrive location
Use one synced project folder, for example:

`OneDrive\Advanced_RPAS\`

Then keep these master files in that folder and have the future HTML/JavaScript quiz tool read/write exported JSON/JSONL/CSV data from the same project.

## Next build step
Recover full question-level records from prior chats/files, assign stable question IDs and TP 15263 domains, then calculate rolling mastery metrics per topic.
