from pathlib import Path
import json, argparse, shutil

def read_jsonl(path):
    if not path.exists(): return []
    rows=[]
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            try: rows.append(json.loads(line))
            except: pass
    return rows

ap=argparse.ArgumentParser()
ap.add_argument("session_file")
ap.add_argument("--repo",default=".")
a=ap.parse_args()

repo=Path(a.repo)
session=json.loads(Path(a.session_file).read_text(encoding="utf-8"))
(repo/"sessions").mkdir(exist_ok=True)
(repo/"incoming").mkdir(exist_ok=True)

archive=repo/"sessions"/Path(a.session_file).name
if not archive.exists():
    shutil.copy2(a.session_file, archive)

qbank=repo/"question_bank.jsonl"
existing={r.get("question_id") for r in read_jsonl(qbank)}
added=0
with qbank.open("a",encoding="utf-8") as f:
    for q in session["questions"]:
        if q["question_id"] in existing: continue
        row=dict(q)
        row["session_id"]=session["session_id"]
        row["date"]=session["date"]
        f.write(json.dumps(row,ensure_ascii=False)+"\n")
        added+=1

idx=repo/"session_index.jsonl"
seen={r.get("session_id") for r in read_jsonl(idx)}
if session["session_id"] not in seen:
    with idx.open("a",encoding="utf-8") as f:
        f.write(json.dumps({
            "session_id":session["session_id"],"date":session["date"],
            "title":session["title"],"score":session["score"],"out_of":session["out_of"],
            "accuracy_pct":session["accuracy_pct"],"readiness":session["readiness"],
            "file":str(Path("sessions")/archive.name)
        },ensure_ascii=False)+"\n")

log=repo/"Advanced_RPAS_Practice_Log.md"
with log.open("a",encoding="utf-8") as f:
    f.write(f"\n### {session['date']} — {session['title']}\n\n")
    f.write(f"- **Session ID:** {session['session_id']}\n")
    f.write(f"- **Score:** {session['score']}/{session['out_of']} ({session['accuracy_pct']:.1f}%)\n")
    f.write(f"- **Readiness:** {session['readiness']}\n")
    f.write(f"- **Question records added:** {added}\n")
    if session.get("reinforcement"):
        f.write("- **Reinforcement:** "+", ".join(x["topic"] for x in session["reinforcement"])+"\n")

print(f"Ingested {session['session_id']}; added {added} questions.")
