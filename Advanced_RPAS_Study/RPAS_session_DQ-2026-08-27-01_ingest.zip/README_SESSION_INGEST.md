# RPAS Session Ingest

Place these in the canonical repository:

- `tools\ingest_session.py`
- `incoming\session_DQ-2026-08-27-01.json`

Then run from PowerShell:

```powershell
$Repo = "C:\Users\rontr\OneDrive\Advanced Study 2027\Advanced_RPAS_Study"
python "$Repo\tools\ingest_session.py" "$Repo\incoming\session_DQ-2026-08-27-01.json" --repo "$Repo"
```

The script will:

1. archive the full session under `sessions\`
2. append its 10 verified questions to `question_bank.jsonl`
3. append the session to `session_index.jsonl`
4. append a concise audit entry to `Advanced_RPAS_Practice_Log.md`
5. skip duplicate question IDs if run twice

Recommended repository layout:

```text
Advanced_RPAS_Study\
  Advanced_RPAS_Practice_Log.md
  question_bank.jsonl
  session_index.jsonl
  sessions\
  incoming\
  tools\
    ingest_session.py
```

Use `sessions\` as the immutable evidence layer and `question_bank.jsonl` as the consolidated Q&QA/mastery layer.
